<?php
include 'conn.php';

if (isset($_POST['query_id'])) {
    $query_id = $_POST['query_id'];

    // Update query status in the database
    $sql = "UPDATE contact_query SET query_status = 1 WHERE query_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $query_id);
    if ($stmt->execute()) {
        echo 'Success';
    } else {
        echo 'Error';
    }
    $stmt->close();
}
?>
