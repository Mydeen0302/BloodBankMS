<?php
// Connect to the database
include 'conn.php';

// Set headers to indicate file download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=queries.csv');

// Open a file pointer connected to the output stream
$output = fopen('php://output', 'w');

// Output column headings
fputcsv($output, array('S.no', 'Name', 'Email Id', 'Mobile Number', 'Message', 'Posting Date', 'Status'));

// Fetch the data from the contact_query table
$sql = "SELECT * FROM contact_query";
$result = mysqli_query($conn, $sql);

// Output each row of the data
$count = 1;
while ($row = mysqli_fetch_assoc($result)) {
    $status = $row['query_status'] == 1 ? 'Read' : 'Pending';
    fputcsv($output, array(
        $count++,
        $row['query_name'],
        $row['query_mail'],
        $row['query_number'],
        $row['query_message'],
        $row['query_date'],
        $status
    ));
}

// Close file pointer
fclose($output);

// Close the database connection
mysqli_close($conn);
?>
