<?php
include 'conn.php';

// Query to fetch the donor data
$sql = "SELECT donor_name, donor_number, donor_mail, donor_age, donor_gender, blood_group, donor_address 
        FROM donor_details 
        JOIN blood ON donor_details.donor_blood = blood.blood_id";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // Set headers to download the file
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=donor_list.csv');

    // Open the output stream
    $output = fopen("php://output", "w");

    // Write the column headers
    fputcsv($output, array('Name', 'Mobile Number', 'Email Id', 'Age', 'Gender', 'Blood Group', 'Address'));

    // Write the donor details row by row
    while ($row = mysqli_fetch_assoc($result)) {
        fputcsv($output, $row);
    }

    // Close the output stream
    fclose($output);
} else {
    echo "No records found.";
}
?>
