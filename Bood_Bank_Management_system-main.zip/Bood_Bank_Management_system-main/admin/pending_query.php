<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        #sidebar {
            position: relative;
            margin-top: -20px;
        }
        #content {
            position: relative;
            margin-left: 210px;
        }
        @media screen and (max-width: 600px) {
            #content {
                position: relative;
                margin-left: auto;
                margin-right: auto;
            }
        }
    </style>
</head>
<body style="color:black">
    <?php
    include 'conn.php';
    include 'session.php';

    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
    ?>
    <div id="header">
        <?php include 'header.php'; ?>
    </div>
    <div id="sidebar">
        <?php $active = "query"; include 'sidebar.php'; ?>
    </div>
    <div id="content">
        <div class="content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 lg-12 sm-12">
                        <h1 class="page-title">Pending Queries</h1>
                    </div>
                </div>
                <hr>
                <script>
                function clickme(query_id) {
                    if (confirm("Do you really want to mark this query as read?")) {
                        $.ajax({
                            url: 'update_query_status.php',
                            type: 'POST',
                            data: { query_id: query_id },
                            success: function(response) {
                                if (response.trim() == 'Success') {
                                    document.getElementById("status" + query_id).innerHTML = "Read";
                                    const actionCell = document.querySelector("#action" + query_id);
                                    actionCell.innerHTML = 'Read';
                                    alert('Status updated successfully!');
                                } else {
                                    alert('Error updating the status. Please try again.');
                                }
                            },
                            error: function() {
                                alert('AJAX request failed. Please try again.');
                            }
                        });
                    }
                }
                </script>

                <?php
                $limit = 10;
                $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                $offset = ($page - 1) * $limit;
                $count = $offset + 1;
                $sql = "SELECT * FROM contact_query WHERE query_status = 0 LIMIT {$offset}, {$limit}";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                ?>

                <div class="table-responsive">
                    <table class="table table-bordered" style="text-align:center">
                        <thead style="text-align:center">
                            <tr>
                                <th style="text-align:center">S.no</th>
                                <th style="text-align:center">Name</th>
                                <th style="text-align:center">Email Id</th>
                                <th style="text-align:center">Mobile Number</th>
                                <th style="text-align:center">Message</th>
                                <th style="text-align:center">Posting Date</th>
                                <th style="text-align:center">Status</th>
                                <th style="text-align:center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($row = mysqli_fetch_assoc($result)) { ?>
                                <tr>
                                    <td><?php echo $count++; ?></td>
                                    <td><?php echo htmlspecialchars($row['query_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['query_mail']); ?></td>
                                    <td><?php echo htmlspecialchars($row['query_number']); ?></td>
                                    <td><?php echo htmlspecialchars($row['query_message']); ?></td>
                                    <td><?php echo htmlspecialchars($row['query_date']); ?></td>
                                    <td><b id="status<?php echo $row['query_id']; ?>"><?php echo $row['query_status'] == 1 ? 'Read' : 'Pending'; ?></b></td>
                                    <td id="action<?php echo $row['query_id']; ?>">
                                        <a style="background-color:aqua" href='delete_query.php?id=<?php echo $row['query_id']; ?>'>Delete</a>
                                        <?php if ($row['query_status'] == 0) { ?>
                                            <a href="#" onclick="clickme(<?php echo $row['query_id']; ?>)">Mark as Read</a>
                                        <?php } else { ?>
                                            Read
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <?php } ?>

                <div class="table-responsive" style="text-align:center">
                    <?php
                    $sql1 = "SELECT * FROM contact_query WHERE query_status = 0";
                    $result1 = mysqli_query($conn, $sql1) or die("Query Failed.");

                    if (mysqli_num_rows($result1) > 0) {
                        $total_records = mysqli_num_rows($result1);
                        $total_page = ceil($total_records / $limit);

                        echo '<ul class="pagination admin-pagination">';
                        if ($page > 1) {
                            echo '<li><a href="pendingquery.php?page='.($page - 1).'">Prev</a></li>';
                        }
                        for ($i = 1; $i <= $total_page; $i++) {
                            $active = $i == $page ? "active" : "";
                            echo '<li class="'.$active.'"><a href="pendingquery.php?page='.$i.'">'.$i.'</a></li>';
                        }
                        if ($total_page > $page) {
                            echo '<li><a href="pendingquery.php?page='.($page + 1).'">Next</a></li>';
                        }
                        echo '</ul>';
                    }
                    ?>
                </div>
            </div>
        </div>
    <?php
    } else {
        echo '<div class="alert alert-danger"><b> Please Login First To Access Admin Portal.</b></div>';
    ?>
        <form method="post" action="login.php" class="form-signin">
            <div align="center">
                <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
            </div>
        </form>
    <?php
    }
    ?>
</body>
</html>
