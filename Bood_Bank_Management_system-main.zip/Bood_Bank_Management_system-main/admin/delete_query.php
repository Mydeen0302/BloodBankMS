<?php
include 'conn.php';

// Check if ID is provided
if (isset($_GET['id'])) {
    $que_id = intval($_GET['id']);

    // Prepare and execute delete query
    $sql = "DELETE FROM contact_query WHERE query_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $que_id);
    $stmt->execute();
    $stmt->close();
}

// Close database connection
mysqli_close($conn);

// Redirect to the queries page
header("Location: query.php");
exit();
?>